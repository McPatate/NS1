#ifndef _GRAPHICSWORKER_HPP_
# define _GRAPHICSWORKER_HPP_

# include <gtkmm.h> // wHUT ?!
# include <thread>
# include <mutex>
# include "LivePacketCapture.hpp"

class					GraphicsWindow;

class					GraphicsWorker
{
public:
  GraphicsWorker();
  virtual ~GraphicsWorker() {}
  
public:
  void do_work(GraphicsWindow* caller);

  void get_data(double* fraction, packet_t *packet) const;
  void stop_work();
  bool has_stopped() const;

private:
  // Synchronizes access to member data.
  mutable std::mutex m_Mutex;

  // Data used by both GUI thread and worker thread.
  bool m_shall_stop;
  bool m_has_stopped;
  double m_fraction;
  packet_t m_packet;
};

#endif // !_GRAPHICSWORKER_HPP_
